#!/bin/bash

#PBS -N count
#PBS -M ca.alvarado@uniandes.edu.co

#PBS -l mem=16gb,vmem=16gb
#PBS -l nodes=1:ppn=6
#PBS -l walltime=05:00:00
#PBS -t 1-50

cd $PBS_O_WORKDIR

module load R/3.1.2

Rscript "count.R" Camilo_calidad_${PBS_ARRAYID}-1.fastq.gz\ _Rsubread.bam