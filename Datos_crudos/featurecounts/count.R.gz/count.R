arg = commandArgs(trailingOnly=TRUE)

setwd("/hpcfs/home/ciencias/biologia/doctorado/ca.alvarado/INTERACTOMA/YUCA/featurecounts")

library(Rsubread)

FeaC1<-featureCounts(files=arg[1], isGTFAnnotationFile=TRUE, annot.ext="Mesculenta_305_v6.1.exons.gtf", GTF.featureType="exon", GTF.attrType="gene_id", useMetaFeatures=TRUE, requireBothEndsMapped=TRUE, isPairedEnd=TRUE, nthreads=6)

write.table(x=data.frame(FeaC1$annotation[,c("GeneID","Length")],FeaC1$counts,stringsAsFactors=FALSE),file=paste("Fcounts_",arg[1],".txt",sep=""),quote=FALSE,sep="\t",row.names=FALSE)